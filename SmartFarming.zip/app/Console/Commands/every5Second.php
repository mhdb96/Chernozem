<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Http\Request;

use Kreait\Firebase;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Database;

use App\Models\Category;

class every5Second extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'second:check';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Check Firebase Data';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/nodemcu-test-2161a-f457b052328a.json');
        $firebase = (new Factory)
            ->withServiceAccount($serviceAccount)
            ->withDatabaseUri('https://nodemcu-test-2161a.firebaseio.com/')
            ->createDatabase();

        $gasLimit          = $firebase->getReference('2C-F4-32-5D-E5-75/Automation/GasLimit')->getSnapshot()->getValue();
        $soilHumidityLimit = $firebase->getReference('2C-F4-32-5D-E5-75/Automation/SoilHumLimit')->getSnapshot()->getValue();
        $tempretureLimit   = $firebase->getReference('2C-F4-32-5D-E5-75/Automation/TempLimit')->getSnapshot()->getValue();
        
        $gasValue = last($firebase->getReference('2C-F4-32-5D-E5-75/Data/Gas')->getSnapshot()->getValue());
        if ($gasValue > $gasLimit)
            echo "Gaz değeri olması gerekenden fazla !!! Fan çalıştırılıyor.<br>";

        $soilHumidityValue = last($firebase->getReference('2C-F4-32-5D-E5-75/Data/SoilHumidity')->getSnapshot()->getValue());
        if ($soilHumidityValue > $soilHumidityLimit)
            echo "Toprak nemi değeri olması gerekenden fazla !!! Su pompası çalıştırılıyor.<br>";

        $tempratureValue = last($firebase->getReference('2C-F4-32-5D-E5-75/Data/Tempreture')->getSnapshot()->getValue());
        if ($tempratureValue > $tempretureLimit)
            echo "Sıcaklık değeri olması gerekenden fazla !!! Fan çalıştırılıyor.<br>";

        $movementValue = last($firebase->getReference('2C-F4-32-5D-E5-75/Data/Movement')->getSnapshot()->getValue());
        if ($movementValue == 1)
            echo "Sera içinde bir hareket algılandı !!! Alarm Çalıştırıldı.<br>";
        
    }
}
