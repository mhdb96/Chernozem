<?php $__env->startSection('title', 'Giriş Reddedildi'); ?>

<?php $__env->startSection('content'); ?>
<div class="alert alert-danger alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <h4><i class="icon fa fa-ban"></i> UYARI!</h4>
    Üzgünüz! Bu sayfaya erişmek için izniniz bulunmuyor.
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SmartFarming\resources\views/permission-denied.blade.php ENDPATH**/ ?>