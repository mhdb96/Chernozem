<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">    
    <?php $__currentLoopData = $dashboardCountList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-<?php echo e($listItem['background']); ?>">
                <div class="inner">
                    <h3><?php echo e($listItem['count']); ?></h3>
                    <p><?php echo e($listItem['name']); ?></p>
                </div>
            <div class="icon">
                <i class="ion ion-bag"></i>
            </div>
        </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
</div>
<?php $__env->stopSection(); ?>   
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SmartFarming\resources\views/dashboard-customer.blade.php ENDPATH**/ ?>