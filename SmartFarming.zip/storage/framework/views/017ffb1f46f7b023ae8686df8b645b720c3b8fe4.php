<?php $__env->startSection('title', ' Kit Ekleme Formu'); ?>

<?php $__env->startSection('content-title', 'asd'); ?>
<?php $__env->startSection('content-description', 'Kit Ekleme Formu'); ?>
<?php $__env->startSection('breadcrumb-title', 'Pakete Kit Ekle'); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .icheckbox_square-blue:last-child { margin-left: 20px; }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="box box-primary">

        <div class="box-header with-border">
          <h3 class="box-title">asd Kit Ekleme Formu</h3>
        </div>

        <form class="form-horizontal" action="<?php echo e(route('project.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="box-body">
                <div class="form-group">
                    <label class="col-sm-2 control-label">İsim</label>  
                    <div class="col-sm-8">
                      <input type="text" class="form-control" id="name" name="name" placeholder="İsim">
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-2 control-label">Başlangıç Tarihi:</label>
                    <div class="col-sm-8">
                        <div class="input-group date">
                            <div class="input-group-addon">
                                <i class="fa fa-calendar"></i>
                            </div>
                            <input type="text" class="form-control pull-right date" id="start_date" name="start_date" placeholder="Projenin Başlangıç Tarihini Seçin">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-2 control-label">Bitiş Tarihi:</label>
                    <div class="col-sm-8">
                        <div class="input-group date">
                            <div class="input-group-addon">
                                <i class="fa fa-calendar"></i>
                            </div>
                            <input type="text" class="form-control pull-right date" id="end_date" name="end_date" placeholder="Projenin Bitiş Tarihini Seçin">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-2 control-label">Paketler</label>
                    <div class="col-sm-8">
                        <select class="form-control select2" style="width: 100%;" name="packet_id" data-placeholder="Paket Türünü Seçin">
                            <option></option>
                            <?php $__currentLoopData = $packets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $packet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($packet->id); ?>"><?php echo e($packet->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="col-sm-2 control-label">Arazi Var mı?</label>
                    <div class="col-sm-8">
                        <input type="radio" name="owns_area" class="minimal" value="1"> Var 
                        <input type="radio" name="owns_area" class="minimal" value="0"> Yok
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-2 control-label">Saha Sayısı</label>  
                    <div class="col-sm-8">
                      <input type="number" class="form-control" id="area_count" name="area_count" placeholder="Saha Sayısı">
                    </div>
                    <div class="col-sm-2">
                        <button class="btn btn-success" id="add-area-inputs">Ekle</button>
                    </div>
                </div>

                <hr>
                
                <div id="listing-area"></div>

            </div>

            <div class="box-footer">
                <a href="<?php echo e(route('project.index')); ?>" class="btn btn-default">Geri</a>
                <button type="submit" class="btn btn-primary pull-right">Ekle</button>
            </div>

        </form>

      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $('.select2').select2();
    $('.date').datepicker({
        format: 'dd/mm/yyyy',
        language: 'tr',
        autoclose: true
    });
    $('input[type="radio"]').iCheck({
        radioClass: 'icheckbox_square-blue'
    }); 

    $('#add-area-inputs').click(function(e) {
        e.preventDefault();
        $('#listing-area').empty();
        var areaCount = $('#area_count')[0].value;
        for (let i = 1; i <= areaCount; i++) {
           $('#listing-area').append(`
                <div class="form-group">
                    <label for="counts" class="col-sm-2 control-label">Sera - ${i}</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control" name="area_names[]" placeholder="Saha Adı">
                    </div>
                </div>  
            `);            
        }
        $('.select2').select2();        
    });
    
</script>
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SmartFarming\resources\views/project/create.blade.php ENDPATH**/ ?>