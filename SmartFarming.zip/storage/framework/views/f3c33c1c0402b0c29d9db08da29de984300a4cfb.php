<section class="content-header">
    <h1>
      <?php echo $__env->yieldContent('content-title'); ?>
      <small><?php echo $__env->yieldContent('content-description'); ?></small>
    </h1>
    <ol class="breadcrumb">
        <li>
          <a href="<?php echo e(route('dashboard')); ?>">
              <i class="fa fa-dashboard"></i> Kontrol Paneli
            </a>
        </li>
        <li class="active"><?php echo $__env->yieldContent('breadcrumb-title'); ?></li>
    </ol>
</section><?php /**PATH C:\xampp\htdocs\SmartFarming\resources\views/layouts/include/content-header.blade.php ENDPATH**/ ?>