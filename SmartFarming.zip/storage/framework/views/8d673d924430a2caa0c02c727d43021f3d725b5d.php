<?php $__env->startSection('title', $sensor->description.' Anlık Veri Akışı'); ?>

<?php $__env->startSection('content-title', $sensor->description); ?>
<?php $__env->startSection('content-description', ' Anlık Veri Akışı'); ?>
<?php $__env->startSection('breadcrumb-title', $sensor->description); ?>

<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <canvas id="line-chart" width="800" height="300"></canvas>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Chart.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
<!-- The core Firebase JS SDK is always required and must be listed first -->
<script src="https://www.gstatic.com/firebasejs/7.6.0/firebase.js"></script>

<script>
    // Your web app's Firebase configuration
    var firebaseConfig = {
        apiKey: "AIzaSyBepTpXlfPbYV0LO9QjvLTjkE1nOMOuhp4",
        authDomain: "nodemcu-test-2161a.firebaseapp.com",
        databaseURL: "https://nodemcu-test-2161a.firebaseio.com",
        projectId: "nodemcu-test-2161a",
        storageBucket: "nodemcu-test-2161a.appspot.com",
        messagingSenderId: "547962417950",
        appId: "1:547962417950:web:db8c6d07ce6b0e20db8f0f",
        measurementId: "G-X8CC3EGR4F"
    };
    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);

    // Get a reference to the database service
    var database = firebase.database();

    $(document).ready(function() { 
        data = [];
        time = [];
        dataLength = 1;
        var fetchedData = firebase.database().ref('2C-F4-32-5D-E5-75/Data/SoilHumidity');
        fetchedData.once('value', function(snapshot) {
            snapshot.forEach(function(childSnapshot) {
                value = childSnapshot.val().value;
                if (value != 0) {
                    data.push(value); 
                    dataLength++; 
                }
            });
            for (let i = 1; i <= dataLength; i++) {
                time.push(i*5);           
            }
            new Chart(document.getElementById("line-chart"), {
                type: 'line',
                data: {
                    labels: time,
                    datasets: [{ 
                        data: data,
                        label: "Gaz",
                        borderColor: "#3e95cd",
                        fill: true
                    }]
                }
            });
        });
    });
    

    
</script>
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SmartFarming\resources\views/sensor/chart.blade.php ENDPATH**/ ?>