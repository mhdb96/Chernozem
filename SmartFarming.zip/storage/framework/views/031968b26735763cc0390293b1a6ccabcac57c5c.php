<?php $__env->startSection('title', $project->name.' Listesi'); ?>

<?php $__env->startSection('content-title', $project->name); ?>
<?php $__env->startSection('content-description', 'Listesi'); ?>
<?php $__env->startSection('breadcrumb-title', $project->name); ?>

<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <?php $__currentLoopData = $projectAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-xs-6">
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h2><?php echo e($item->name); ?></h2>
                    </div>
                    <div class="icon greenhouse"></div>
                    <a href="<?php echo e(route('project-area.show', $item->id)); ?>" class="small-box-footer">
                        İncele <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
 
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SmartFarming\resources\views/project/index.blade.php ENDPATH**/ ?>