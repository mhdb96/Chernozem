<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function(){
    selectValues = $('[name ="soils[]"]').val();

    var controlData = [];
    $.ajax({
        type:'GET',
        url:'/control-data',
        data:{
            region_id: <?php echo e($data->id); ?>,
            soilIds: selectValues
        },
        success:function(data){   
            data.forEach(item => controlData.push(item));
        }
    }); 

    $('[name ="soils[]"]').on("select2:unselecting", function(e) {        

        controlData.forEach(item => {
            if (item.soil_id == e.params.args.data.id && item.isOpen == true) {                
                e.preventDefault();
                $('#showDeleteMessage').modal('show');
            } else {
                return true;
            }
        });          
    });
});


</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.partial.edit.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SmartFarming\resources\views/region/edit.blade.php ENDPATH**/ ?>