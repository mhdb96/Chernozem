<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
      <?php echo $__env->make('layouts.include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="col-xs-12">
        <div class="box box-primary">
          <div class="box-header" style="padding: 20px 10px">
            <h3 class="box-title"><?php echo e($title); ?> Türleri</h3>
            <div class="box-tools" style="top: 12px">
              <a href="<?php echo e(route($route.'.create')); ?>" class="btn btn-block btn-success">
                <i class="fa fa-plus"></i> Yeni Ekle
              </a>
            </div>
          </div>
          <div class="box-body table-responsive no-padding">
            <table class="table table-hover">
              <tbody><tr>
                <th style="width: 35px">#</th>
                <?php $__currentLoopData = $fillables_titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fillable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th style="width: 200px"><?php echo e($fillable); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <th style="width: <?php echo e($empty_space); ?>px;"></th>
              </tr>
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e(++$key); ?></td>
                  <?php $__currentLoopData = $fillables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fillable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                  
                  <?php if(is_array($item->$fillable)): ?>                
                    <td style="width : 500px;">
                      <?php $__currentLoopData = $item->$fillable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                            
                      <?php echo e($f); ?> <br>                      
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                  <?php else: ?>
                    <td><?php echo e($item->$fillable); ?></td>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  <td style="text-align: right;">
                    <a href="<?php echo e(route($route.'.edit', $item->id)); ?>" class="btn btn-sm btn-info" data-toggle="tooltip" data-placement="bottom" title="Düzenle">
                      <i class="fa fa-pencil"></i>
                    </a>
                    <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#deleteModal" onclick="deleteData(<?php echo e($item->id); ?>, '<?php echo e($route); ?>')">
                        <i class="fa fa-trash"></i>
                    </button>

                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
    </div>
</section>

<div class="modal fade" id="deleteModal">
    <div class="modal-dialog">
      <div class="modal-content">
        <form action="" method="POST" id="deleteForm">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span></button>
            <h4 class="modal-title">UYARI</h4>
          </div>
          <div class="modal-body">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <p>Bu <?php echo e($title); ?> türünü silmek istediğinizden emin misiniz?</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Hayır</button>
            <button type="button" class="btn btn-primary" onclick="formSubmit()">Evet</button>
          </div>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
  <script type="text/javascript">
    function deleteData(id, route)
    {
        var id = id;
        var url = `<?php echo e(route("${route}.destroy", ":id")); ?>`;
        url = url.replace(':id', id);
        $("#deleteForm").attr('action', url);
    }

    function formSubmit()
    {
        $("#deleteForm").submit();
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.partial.container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SmartFarming\resources\views/layouts/partial/index.blade.php ENDPATH**/ ?>