<?php $__env->startSection('title', $projectArea->name.' Kit Listesi'); ?>

<?php $__env->startSection('content-title', $projectArea->name); ?>
<?php $__env->startSection('content-description', 'Kit Listesi'); ?>
<?php $__env->startSection('breadcrumb-title', $projectArea->name); ?>

<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">

        <?php echo $__env->make('layouts.include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php $__currentLoopData = $kits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-xs-6">
                <div class="small-box bg-green">
                    <div class="inner">
                        <h2><?php echo e($item->name); ?></h2>
                    </div>
                    <div class="icon sensor"></div>
                    <a href="<?php echo e(route('kit.show', $item->id)); ?>?project_area_id=<?php echo e($projectArea->id); ?>" class="small-box-footer">
                        İncele <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
 
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SmartFarming\resources\views/project-area/index.blade.php ENDPATH**/ ?>