<aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(asset('dist/img/user2-160x160.jpg')); ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">            
            <?php if(Auth::user()->role->name == 'admin'): ?>
                <p><?php echo e(Auth::user()->admin->first_name); ?> <?php echo e(Auth::user()->admin->last_name); ?></p>
            <?php else: ?>
                <p><?php echo e(Auth::user()->customer->first_name); ?> <?php echo e(Auth::user()->customer->last_name); ?></p>
            <?php endif; ?>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">İşlemler Menüsü</li>
        <!-- Optionally, you can add icons to the links -->
        <li class="<?php echo e(Request::is('dashboard*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('dashboard')); ?>">
                <i class="fa fa-dashboard"></i>
                <span>Kontrol Paneli</span>
            </a>
        </li>
        
        <?php if(Auth::user()->role->name == 'admin'): ?>
        <li class="treeview <?php echo e(Request::is('soil*') || Request::is('region*') || Request::is('packet*') || Request::is('plant*') || Request::is('area*') ||  Request::is('area-capacity*') ? 'menu-open' : ''); ?>">
            <a href="#"><i class="fa fa-link"></i> <span>Paketlerimiz</span>
              <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
            </a>
            <ul 
                class="treeview-menu" 
                style="<?php echo e(Request::is('soil*') || Request::is('region*') || Request::is('packet*') || Request::is('plant*') || Request::is('area') || Request::is('area/*') ||  Request::is('area-capacity*') ? 'display: block' : ''); ?>">
                <li class="<?php echo e(Request::is('packet*') && !Request::is('packet-*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('packet.index')); ?>">
                        <span>Paket İşlemleri</span>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('packet-kit*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('packet-kit.index')); ?>">
                        <span>Paketlere Kit Ekle</span>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('soil*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('soil.index')); ?>">
                        <span>Toprak İşlemleri</span>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('region*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('region.index')); ?>">
                        <span>İklim İşlemleri</span>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('plant*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('plant.index')); ?>">
                        <span>Bitki İşlemleri</span>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('area*') && !Request::is('area-*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('area.index')); ?>">
                        <span>Saha İşlemleri</span>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('area-capacity*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('area-capacity.index')); ?>">
                        <span>Saha Kapasite İşlemleri</span>
                    </a>
                </li>
            </ul>
          </li>
        <li class="treeview <?php echo e(Request::is('kit*') || Request::is('input*') || Request::is('action*') || Request::is('sensor*') || Request::is('actuator*') || Request::is('controller*') ? 'menu-open' : ''); ?>">
          <a href="#"><i class="fa fa-link"></i> <span>Kitlerimiz</span>
            <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
          </a>
          <ul class="treeview-menu" style="<?php echo e(Request::is('kit*') || Request::is('input*') || Request::is('action*') || Request::is('sensor*') || Request::is('actuator*') || Request::is('controller*') ? 'display: block' : ''); ?>">
            <li class="<?php echo e(Request::is('kit*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('kit.index')); ?>">
                    <span>Kit İşlemleri</span>
                </a>
            </li>
            <li class="<?php echo e(Request::is('input*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('input.index')); ?>">
                    <span>Giriş İşlemleri</span>
                </a>
            </li>
            <li class="<?php echo e(Request::is('action*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('action.index')); ?>">
                    <span>Eylem İşlemleri</span>
                </a>
            </li>
            <li class="<?php echo e(Request::is('sensor*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('sensor.index')); ?>">
                    <span>Sensor İşlemleri</span>
                </a>
            </li>
            <li class="<?php echo e(Request::is('actuator*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('actuator.index')); ?>">
                    <span>Eyleyici İşlemleri</span>
                </a>
            </li>
            <li class="<?php echo e(Request::is('controller*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('controller.index')); ?>">
                    <span>Kontrolor İşlemleri</span>
                </a>
            </li>
          </ul>
        </li>
        <li class="treeview <?php echo e(Request::is('category*') || Request::is('type*') || Request::is('unit*') ? 'menu-open' : ''); ?>">
            <a href="#"><i class="fa fa-link"></i> <span>Diger</span>
              <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
            </a>
            <ul class="treeview-menu" style="<?php echo e(Request::is('category*') || Request::is('type*') || Request::is('unit*') ? 'display: block' : ''); ?>">
                <li class="<?php echo e(Request::is('category*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('category.index')); ?>">
                        <span>Kategori İşlemleri</span>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('type*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('type.index')); ?>">
                        <span>Tip İşlemleri</span>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('unit*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('unit.index')); ?>">
                        <span>Birim İşlemleri</span>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('project-area-kit*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('project-area-kit.index')); ?>">
                        <span>Mac İşlemleri</span>
                    </a>
                </li>
            </ul>
        </li>

        <?php endif; ?>

        <?php if(Auth::user()->role->name == 'customer'): ?>
        <li class="treeview">
            <a href="#">
              <i class="fa fa-edit"></i> <span>Proje İşlemleri</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            <ul class="treeview-menu" style="display: none;">
                <li><a href="<?php echo e(route('project.create')); ?>">Proje Oluştur</a></li>

                <?php $__currentLoopData = \App\Models\Project::where('customer_id','=',Auth::user()->customer->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('project.show', $project->id)); ?>"><?php echo e($project->name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>
        </li>
        <?php endif; ?>

        <li class="treeview"> 
            <a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <i class="fa fa-power-off"></i> Çıkış Yap
            </a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="post" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        </li>

      
      
      </ul>
      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>
<?php /**PATH C:\xampp\htdocs\SmartFarming\resources\views/layouts/include/sidebar.blade.php ENDPATH**/ ?>