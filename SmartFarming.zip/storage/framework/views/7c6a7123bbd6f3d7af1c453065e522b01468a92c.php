<div class="box-body" id="box-body">
    <div class="col-sm-12 input-box">      
        <?php $__currentLoopData = $fillables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $fillable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
        <div class="form-group">
            <?php if($fillables_types[$key] == 'many'): ?>            
            <label for="<?php echo e($fillable->first()->getTable()); ?>" class="col-sm-2 control-label"><?php echo e($fillables_titles[$key]); ?> Türleri</label>
            <div class="col-sm-8">
                  <select class="form-control select2" 
                  multiple="multiple" name="<?php echo e($fillable->first()->getTable()); ?>[]" data-placeholder="<?php echo e($fillables_titles[$key]); ?> Türlerini Seçin" style="width: 100%;">
                  <?php $__currentLoopData = $fillable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                      <option value="<?php echo e($item->id); ?>"><?php echo e($item->name()); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
            </div>
            <?php elseif($fillables_types[$key] == 'one'): ?>           
            <label for="<?php echo e($fillable->first()->getTable()); ?>" class="col-sm-2 control-label"><?php echo e($fillables_titles[$key]); ?> Türleri</label>
            <div class="col-sm-8">
                  <select class="form-control select2" name="<?php echo e($fillable->first()->getTable()); ?>" data-placeholder="<?php echo e($fillables_titles[$key]); ?> Türlerini Seçin" style="width: 100%;">
                    <option></option>                    
                    <?php $__currentLoopData = $fillable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                    
                      <option value="<?php echo e($item->id); ?>"><?php echo e($item->name()); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
            </div>
            <?php elseif($fillables_types[$key] == 'auto'): ?>            
            <label for="<?php echo e($fillable->first()->getTable()); ?>" class="col-sm-2 control-label"><?php echo e($fillables_titles[$key]); ?> Türleri</label>
            <div class="col-sm-8">
                  <select class="form-control select2" name="<?php echo e($fillable->first()->getTable()); ?>" data-placeholder="<?php echo e($fillables_titles[$key]); ?> Türlerini Seçin" style="width: 100%;">
                    <option></option>
                    
                  </select>
            </div>
            <?php else: ?> 
            <label for="<?php echo e($fillable); ?>" class="col-sm-2 control-label"><?php echo e($fillables_titles[$key]); ?></label>
            <div class="col-sm-8">
              <input type="text" class="form-control"
              name="<?php echo e($is_multiple ? $fillable.'[]' : $fillable.''); ?>"
              id="<?php echo e($fillable); ?>"
              placeholder="<?php echo e($fillables_titles[$key]); ?> Giriniz">
            </div>
            <?php endif; ?>
        </div>        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($is_multiple): ?>
            <div class="form-group">
                <div class="col-sm-2">
                    <button type="button" class="btn btn-block btn-success" style="margin-top: -25px" id="add-button">
                        <i class="fa fa-plus"></i> Ekle
                    </button>
                </div>
            </div>
        <?php endif; ?>
    </div>
  </div>
<?php /**PATH C:\xampp\htdocs\SmartFarming\resources\views/layouts/partial/create/form-content.blade.php ENDPATH**/ ?>