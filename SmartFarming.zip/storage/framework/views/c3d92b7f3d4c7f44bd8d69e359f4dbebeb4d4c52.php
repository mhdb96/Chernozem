<?php $__env->startSection('content-title', $title.' Türleri'); ?>
<?php $__env->startSection('content-description', $data->name.' Güncelle'); ?>

<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">

          <div class="box-header with-border">
            <h3 class="box-title"><?php echo e($data->name); ?> Güncelle</h3>
          </div>

          <form class="form-horizontal" action="<?php echo e(route($route.'.update', $data->id)); ?>" method="POST">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>

            <?php echo $__env->make('layouts.partial.edit.form-content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="box-footer">
                <a href="<?php echo e(route($route.'.index')); ?>" class="btn btn-default">Geri</a>
                <button type="submit" class="btn btn-primary pull-right">Güncelle</button>
            </div>
          </form>
        </div>
      </div>
    </div>
</section>

<div class="modal fade" id="showDeleteMessage">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span></button>
        <h4 class="modal-title">UYARI</h4>
      </div>
      <div class="modal-body">
          <p>Bu bilgiyi silemezsiniz.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Tamam</button>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
  $(document).ready(function() {
    $('.select2').select2();
  });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.partial.container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SmartFarming\resources\views/layouts/partial/edit/form.blade.php ENDPATH**/ ?>