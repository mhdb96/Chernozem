<div class="box-body">
    <?php $__currentLoopData = $fillables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $fillable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <div class="form-group">
      <?php if($fillables_types[$key] == 'many'): ?>
        <label for="<?php echo e($fillable[0]->first()->getTable()); ?>" class="col-sm-2 control-label"><?php echo e($fillables_titles[$key]); ?> Türleri</label>
        <div class="col-sm-8">
          <select class="form-control select2" multiple="multiple" name="<?php echo e($fillable[0]->first()->getTable()); ?>[]" data-placeholder="<?php echo e($fillables_titles[$key]); ?> Türlerini Seçin" style="width: 100%;" required>
            <?php $__currentLoopData = $fillable[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($item->id); ?>" <?php echo e(in_array($item->id, $fillable[1]) ? 'selected' : ''); ?> on><?php echo e($item->name()); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <?php elseif($fillables_types[$key] == 'one'): ?>
        <label for="<?php echo e($fillable[0]->first()->getTable()); ?>" class="col-sm-2 control-label"><?php echo e($fillables_titles[$key]); ?> Türleri</label>
        <div class="col-sm-8">
          <select class="form-control select2" name="<?php echo e($fillable[0]->first()->getTable()); ?>" data-placeholder="<?php echo e($fillables_titles[$key]); ?> Türlerini Seçin" style="width: 100%;" required>
            <?php $__currentLoopData = $fillable[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($item->id); ?>" <?php echo e(in_array($item->id, $fillable[1]) ? 'selected' : ''); ?>><?php echo e($item->name()); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <?php elseif($fillables_types[$key] == 'auto'): ?>
        <label for="<?php echo e($fillable[0]->first()->getTable()); ?>" class="col-sm-2 control-label"><?php echo e($fillables_titles[$key]); ?> Türleri</label>
        <div class="col-sm-8">
          <select class="form-control select2" name="<?php echo e($fillable[0]->first()->getTable()); ?>" data-placeholder="<?php echo e($fillables_titles[$key]); ?> Türlerini Seçin" style="width: 100%;" required>
            <?php if(count($fillable[0]) > 1): ?>
              <?php $__currentLoopData = $fillable[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>" <?php echo e(in_array($item->id, $fillable[1]) ? 'selected' : ''); ?>><?php echo e($item->name()); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>            
              <option value="<?php echo e($fillable[1][0]); ?>" selected><?php echo e($fillable[0]->first()->name()); ?></option>
            <?php endif; ?>                          
          </select>
        </div>
        <?php else: ?>
            <label for="<?php echo e($fillable); ?>" class="col-sm-2 control-label"><?php echo e($fillables_titles[$key]); ?></label>
            <div class="col-sm-8">
                <input type="text" class="form-control" name=<?php echo e($fillable); ?> id=<?php echo e($fillable); ?> placeholder="<?php echo e($fillables_titles[$key]); ?> Giriniz" value="<?php echo e($data->$fillable); ?>" required>
            </div>
        <?php endif; ?>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php /**PATH C:\xampp\htdocs\SmartFarming\resources\views/layouts/partial/edit/form-content.blade.php ENDPATH**/ ?>