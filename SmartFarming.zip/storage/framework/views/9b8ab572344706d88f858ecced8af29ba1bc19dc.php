<?php $__env->startSection('title', $title.' Türleri'); ?>
<?php $__env->startSection('breadcrumb-title', $title.' Türleri'); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SmartFarming\resources\views/layouts/partial/container.blade.php ENDPATH**/ ?>