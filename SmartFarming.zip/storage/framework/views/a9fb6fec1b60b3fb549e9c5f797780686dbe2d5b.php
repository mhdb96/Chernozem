
<div class="row input-box">
<div class="col-sm-10">
    <?php $__currentLoopData = $fillables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $fillable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-group">
            <label for="name" class="col-sm-2 control-label"><?php echo e($fillables_titles[$key]); ?></label>
            <div class="col-sm-8">
                <input type="text" class="form-control" name="<?php echo e($fillable); ?>[]" placeholder="<?php echo e($fillables_titles[$key]); ?> Türü">
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="col-sm-2">
    <button type="button" class="btn btn-block btn-danger remove-button" style="margin-top: -25px">
        <i class="fa fa-trash"></i> Kaldır
    </button>
</div>
</div>

<?php /**PATH C:\xampp\htdocs\SmartFarming\resources\views/layouts/partial/create/dynamic.blade.php ENDPATH**/ ?>