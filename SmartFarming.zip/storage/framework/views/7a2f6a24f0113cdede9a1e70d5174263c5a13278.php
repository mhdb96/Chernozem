<?php $__env->startSection('title', $input->name.' Anlık Veri Akışı'); ?>

<?php $__env->startSection('content-title', $input->name); ?>
<?php $__env->startSection('content-name', ' Anlık Veri Akışı'); ?>
<?php $__env->startSection('breadcrumb-title', $input->name); ?>

<?php $__env->startSection('content'); ?>
<section class="content">    
    <div class="row">
        <div class="col-xs-12">
            <canvas id="input-chart" width="800" height="300"></canvas>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Chart.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.6.0/firebase.js"></script>
<script src="<?php echo e(asset('js/firebase.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.flot.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.flot.resize.js')); ?>"></script>

<script>
    $(document).ready(function() { 
        var chart = document.getElementById("input-chart").getContext("2d");  
        var fetchedData = firebase.database().ref('<?php echo e($mac_adress); ?>/Data/<?php echo e($input->firebase_code); ?>');

        drawChart(chart, fetchedData, '<?php echo e($input->firebase_code); ?>', '<?php echo e($input->name); ?>');

        setInterval(function() {            
            drawChart(chart, fetchedData, '<?php echo e($input->firebase_code); ?>', '<?php echo e($input->name); ?>');
        }, 5000);
    });
</script>    
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SmartFarming\resources\views/input/chart.blade.php ENDPATH**/ ?>