<?php $__env->startSection('content-title', $title.' Türleri'); ?>
<?php $__env->startSection('content-description', 'Yeni '.$title.' Türleri Ekle'); ?>

<?php $__env->startSection('content'); ?>
<section class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Yeni <?php echo e($title); ?> Türleri Ekle</h3>
        </div>
        <form class="form-horizontal" action="<?php echo e(route($route.'.store')); ?>" method="POST">
          <?php echo csrf_field(); ?>

          <?php echo $__env->make('layouts.partial.create.form-content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <div class="box-footer">
            <a href="<?php echo e(route($route.'.index')); ?>" class="btn btn-default">Geri</a>
            <button type="submit" class="btn btn-primary pull-right">Ekle</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
  <script>
    $(document).ready(function(){
      $("#add-button").click(function(){
        $(".box-body").append(`<?php echo $__env->make('layouts.partial.create.dynamic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>`);
      });

      $('.select2').select2();

      $("#box-body").on("click", ".remove-button", function(){
        var t = $(this).offsetParent()[0].parentElement;
        t.remove();
        });
      });
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.partial.container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SmartFarming\resources\views/layouts/partial/create/form.blade.php ENDPATH**/ ?>