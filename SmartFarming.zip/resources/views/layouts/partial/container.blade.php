@extends('layouts.master')
@section('title', $title.' Türleri')
@section('breadcrumb-title', $title.' Türleri')
